# Kafo

---

# BIO

* Marek Hulán
* IRC: mhulan #theforeman on freenode
* GitHub: ares
* work @ RedHat on Foreman project

---

# Overview of this presentation
* What's Kafo
* Creation of installer - live demo

<br />

     !sh
     echo "include $kafo_magic" | puppet apply

Now you know what's kafo

---

# RTFC

For those who would rather see the code instead of demo
https://github.com/theforeman/kafo
<br />
<br />
![qrcode](qrcode.png)


